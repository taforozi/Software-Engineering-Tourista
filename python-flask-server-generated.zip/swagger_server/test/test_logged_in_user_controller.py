# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.location import Location  # noqa: E501
java.util.Map  # noqa: E501
from swagger_server.models.trip_plan import TripPlan  # noqa: E501
from swagger_server.test import BaseTestCase


class TestLoggedInUserController(BaseTestCase):
    """LoggedInUserController integration test stubs"""

    def test_enter_new_locations(self):
        """Test case for enter_new_locations

        Logged in user enters new locations in the database
        """
        newLocation = Location()
        response = self.client.open(
            '/geogiannokosta/TouristaAPI/1.0.0/user/{username}/location'.format(username='username_example'),
            method='POST',
            data=json.dumps(newLocation),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_organise_trip(self):
        """Test case for organise_trip

        A logged in user organise their trip or asks the system to organise a trip for them
        """
        TripPlan = TripPlan()
        query_string = [('willToReceiveAutomaticPlan', true)]
        response = self.client.open(
            '/geogiannokosta/TouristaAPI/1.0.0/user/{username}/tripPlan/{planID}'.format(username='username_example', planID='planID_example'),
            method='POST',
            data=json.dumps(TripPlan),
            content_type='application/json',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_save_map(self):
        """Test case for save_map

        Logged in user saves map
        """
        Map = Map()
        query_string = [('willToSave', true)]
        response = self.client.open(
            '/geogiannokosta/TouristaAPI/1.0.0/user/{username}/map/{mapID}'.format(username='username_example', mapID='mapID_example'),
            method='PUT',
            data=json.dumps(Map),
            content_type='application/json',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_share_map(self):
        """Test case for share_map

        Logged in user shares map
        """
        Map = Map()
        query_string = [('willToShare', true)]
        response = self.client.open(
            '/geogiannokosta/TouristaAPI/1.0.0/user/{username}/map/{mapID}'.format(username='username_example', mapID='mapID_example'),
            method='GET',
            data=json.dumps(Map),
            content_type='application/json',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_share_trip(self):
        """Test case for share_trip

        A logged in user shares their trip plan
        """
        TripPlan = TripPlan()
        query_string = [('willToShare', true)]
        response = self.client.open(
            '/geogiannokosta/TouristaAPI/1.0.0/user/{username}/tripPlan/{planID}'.format(username='username_example', planID='planID_example'),
            method='GET',
            data=json.dumps(TripPlan),
            content_type='application/json',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_use_map_offline(self):
        """Test case for use_map_offline

        Logged in user uses saved map offline
        """
        query_string = [('offlineUse', true)]
        response = self.client.open(
            '/geogiannokosta/TouristaAPI/1.0.0/user/{username}/map/{mapID}/mapUse'.format(username='username_example', mapID='mapID_example'),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
