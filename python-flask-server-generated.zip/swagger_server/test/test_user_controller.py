# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.feedback import Feedback  # noqa: E501
from swagger_server.models.filters import Filters  # noqa: E501
from swagger_server.models.gps_location import GPSLocation  # noqa: E501
java.util.Map  # noqa: E501
from swagger_server.models.token import Token  # noqa: E501
from swagger_server.models.trip import Trip  # noqa: E501
from swagger_server.models.user import User  # noqa: E501
from swagger_server.test import BaseTestCase


class TestUserController(BaseTestCase):
    """UserController integration test stubs"""

    def test_basic_info(self):
        """Test case for basic_info

        Submit basic info
        """
        basicInfo = Trip()
        response = self.client.open(
            '/geogiannokosta/TouristaAPI/1.0.0/user/{userID}/trip/{tripID}'.format(userID='userID_example', tripID='tripID_example'),
            method='POST',
            data=json.dumps(basicInfo),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_choose_filters(self):
        """Test case for choose_filters

        Enter preferences
        """
        Filters = Filters()
        response = self.client.open(
            '/geogiannokosta/TouristaAPI/1.0.0/user/{userID}/filters'.format(userID='userID_example'),
            method='PUT',
            data=json.dumps(Filters),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_enter_currency(self):
        """Test case for enter_currency

        Enter currency of their country
        """
        response = self.client.open(
            '/geogiannokosta/TouristaAPI/1.0.0/user/{userID}/trip/{tripID}'.format(userID='userID_example', tripID='tripID_example'),
            method='PUT',
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_feedback(self):
        """Test case for feedback

        Leave feedback
        """
        Feeback = Feedback()
        response = self.client.open(
            '/geogiannokosta/TouristaAPI/1.0.0/user/{userID}/feedback'.format(userID='userID_example'),
            method='POST',
            data=json.dumps(Feeback),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_gpslocation(self):
        """Test case for gpslocation

        Enable GPS services
        """
        gpsLocation = GPSLocation()
        response = self.client.open(
            '/geogiannokosta/TouristaAPI/1.0.0/user/{userID}/gpsLocation'.format(userID='userID_example'),
            method='PUT',
            data=json.dumps(gpsLocation),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_logg_in(self):
        """Test case for logg_in

        Log in to the system
        """
        User = User()
        response = self.client.open(
            '/geogiannokosta/TouristaAPI/1.0.0/user/login',
            method='PUT',
            data=json.dumps(User),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
