import connexion
import six

from swagger_server.models.location import Location  # noqa: E501
java.util.Map  # noqa: E501
from swagger_server.models.trip_plan import TripPlan  # noqa: E501
from swagger_server import util


def enter_new_locations(username, newLocation):  # noqa: E501
    """Logged in user enters new locations in the database

    FR11 - A logged in user should have been able to enter new locations in the database.  # noqa: E501

    :param username: The username
    :type username: str
    :param newLocation: Location Model
    :type newLocation: dict | bytes

    :rtype: Map
    """
    if connexion.request.is_json:
        newLocation = Location.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def organise_trip(username, TripPlan, planID, willToReceiveAutomaticPlan):  # noqa: E501
    """A logged in user organise their trip or asks the system to organise a trip for them

    FR6 - A logged in user must be able to organise their trip FR7 - The system should be able to organise a trip The user wants to plan a trip. He has the options either to create it by himself or get it done by the system. In both cases a new trip is planned, that&#39;s why POST verb is used.   # noqa: E501

    :param username: User wants to organise their trip
    :type username: str
    :param TripPlan: TripPlan Model
    :type TripPlan: dict | bytes
    :param planID: Trip plan&#39;s ID
    :type planID: str
    :param willToReceiveAutomaticPlan: Whether the logged in user wants to get a plan made by the system or not
    :type willToReceiveAutomaticPlan: bool

    :rtype: TripPlan
    """
    if connexion.request.is_json:
        TripPlan = TripPlan.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def save_map(username, mapID, Map, willToSave):  # noqa: E501
    """Logged in user saves map

    FR9 - A logged in user should have been able to save a map  # noqa: E501

    :param username: The username
    :type username: str
    :param mapID: Map&#39;s ID
    :type mapID: str
    :param Map: Map Model
    :type Map: dict | bytes
    :param willToSave: Whether the logged in user wants to save a map or not
    :type willToSave: bool

    :rtype: Map
    """
    if connexion.request.is_json:
        Map = Map.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def share_map(username, mapID, Map, willToShare):  # noqa: E501
    """Logged in user shares map

    FR8 - A logged in user should be able to share a capture of a map  # noqa: E501

    :param username: The username
    :type username: str
    :param mapID: Map&#39;s ID
    :type mapID: str
    :param Map: Map Model
    :type Map: dict | bytes
    :param willToShare: Whether the logged in user wants to share a map or not
    :type willToShare: bool

    :rtype: Map
    """
    if connexion.request.is_json:
        Map = Map.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def share_trip(username, planID, TripPlan, willToShare):  # noqa: E501
    """A logged in user shares their trip plan

    FR8 - A logged in user should be able to share a trip plan  # noqa: E501

    :param username: The username
    :type username: str
    :param planID: Trip plan&#39;s ID
    :type planID: str
    :param TripPlan: TripPlan Model
    :type TripPlan: dict | bytes
    :param willToShare: Whether the logged inuser wants to share a trip plan or not
    :type willToShare: bool

    :rtype: None
    """
    if connexion.request.is_json:
        TripPlan = TripPlan.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def use_map_offline(username, mapID, offlineUse):  # noqa: E501
    """Logged in user uses saved map offline

    FR10 - A logged in user should have been able to use saved maps offline.  # noqa: E501

    :param username: The username
    :type username: str
    :param mapID: Map&#39;s ID
    :type mapID: str
    :param offlineUse: Whether the logged in user wants to use a saved map offline
    :type offlineUse: bool

    :rtype: Map
    """
    return 'do some magic!'
