import connexion
import six

from swagger_server.models.feedback import Feedback  # noqa: E501
from swagger_server.models.filters import Filters  # noqa: E501
from swagger_server.models.gps_location import GPSLocation  # noqa: E501
java.util.Map  # noqa: E501
from swagger_server.models.token import Token  # noqa: E501
from swagger_server.models.trip import Trip  # noqa: E501
from swagger_server.models.user import User  # noqa: E501
from swagger_server import util


def basic_info(basicInfo, userID, tripID):  # noqa: E501
    """Submit basic info

    FR 1 - A user must be able to submit the basic information for their trip.  # noqa: E501

    :param basicInfo: Trip Model
    :type basicInfo: dict | bytes
    :param userID: User&#39;s ID
    :type userID: str
    :param tripID: Trip&#39;s ID
    :type tripID: str

    :rtype: None
    """
    if connexion.request.is_json:
        basicInfo = Trip.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def choose_filters(Filters, userID):  # noqa: E501
    """Enter preferences

    FR4 - A user must be able to select among the available filter categories  # noqa: E501

    :param Filters: Filters model
    :type Filters: dict | bytes
    :param userID: User&#39;s ID
    :type userID: str

    :rtype: Map
    """
    if connexion.request.is_json:
        Filters = Filters.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def enter_currency(userID, tripID):  # noqa: E501
    """Enter currency of their country

    FR3 - A user should have been able to enter their country&#39;s currency  # noqa: E501

    :param userID: User&#39;s ID
    :type userID: str
    :param tripID: Trip&#39;s ID
    :type tripID: str

    :rtype: None
    """
    return 'do some magic!'


def feedback(Feeback, userID):  # noqa: E501
    """Leave feedback

    FR5 - The user must be able to evaluate the system.  # noqa: E501

    :param Feeback: Feedback model
    :type Feeback: dict | bytes
    :param userID: User&#39;s ID
    :type userID: str

    :rtype: None
    """
    if connexion.request.is_json:
        Feeback = Feedback.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def gpslocation(gpsLocation, userID):  # noqa: E501
    """Enable GPS services

    FR2 - A user must be able to turn their GPS service on.  # noqa: E501

    :param gpsLocation: GPSLocation model
    :type gpsLocation: dict | bytes
    :param userID: User&#39;s ID
    :type userID: str

    :rtype: GPSLocation
    """
    if connexion.request.is_json:
        gpsLocation = GPSLocation.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def logg_in(User):  # noqa: E501
    """Log in to the system

    FR* - A user must be able to login to their account by | providing their username and password.  # noqa: E501

    :param User: User Model
    :type User: dict | bytes

    :rtype: Token
    """
    if connexion.request.is_json:
        User = User.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
